import Web_Interface.app

def main():
    Web_Interface.app.start()

if __name__ == "__main__":
    main()
